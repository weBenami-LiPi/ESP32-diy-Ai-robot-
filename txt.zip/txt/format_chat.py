import re

input_file = r'c:\Users\SHAWON\OneDrive\Desktop\txt\Karib_Bengali.txt'
output_file = r'c:\Users\SHAWON\OneDrive\Desktop\txt\Karib_Bengali_Formatted.txt'

def format_chat():
    with open(input_file, 'r', encoding='utf-8') as f_in:
        content = f_in.read()
    
    # Remove line numbers at the beginning of each line (e.g., "  1 | ")
    content = re.sub(r'^\s*\d+\s*\|\s*', '', content, flags=re.MULTILINE)
    
    # Split into lines for processing
    lines = content.split('\n')
    
    result_parts = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # First, remove all occurrences of "- মার্বান" and "- কারিবঃ" patterns from the line
        # and determine the speaker based on the LAST occurrence
        
        speaker = None
        message = line
        
        # Find all speaker attributions in the line
        # We need to find the last one to determine the speaker
        
        # Pattern for মার্বান (user 1): various forms like "- মার্বান", "-  মার্বান", "- মার্বান!", etc.
        marban_pattern = r'\s*-\s*মার্বান!?\s*'
        # Pattern for কারিবঃ (user 2)
        karib_pattern = r'\s*-\s*কারিবঃ\s*'
        
        # Find all matches and their positions
        marban_matches = list(re.finditer(marban_pattern, line))
        karib_matches = list(re.finditer(karib_pattern, line))
        
        # Determine the last speaker attribution
        last_match = None
        last_pos = -1
        
        for m in marban_matches:
            if m.end() > last_pos:
                last_pos = m.end()
                last_match = ('marban', m)
        
        for m in karib_matches:
            if m.end() > last_pos:
                last_pos = m.end()
                last_match = ('karib', m)
        
        if last_match:
            speaker_type, match = last_match
            if speaker_type == 'marban':
                speaker = 'user 1; '
            else:
                speaker = 'user 2; '
            
            # Remove ALL speaker attributions from the message
            message = re.sub(marban_pattern, '', line)
            message = re.sub(karib_pattern, '', message)
            message = message.strip()
        else:
            # Check for standalone speaker names
            if line == '- মার্বান' or line == 'মার্বান':
                message = ''
                speaker = 'user 1; '
            elif line == '- কারিবঃ' or line == 'কারিবঃ':
                message = ''
                speaker = 'user 2; '
        
        # Build the result
        if speaker:
            if message:
                result_parts.append(f'\n{speaker}{message}')
            else:
                result_parts.append(f'\n{speaker}')
        else:
            # No speaker found, just add the line
            result_parts.append(line)
    
    # Join all parts
    result = ''.join(result_parts)
    
    # Remove leading newline if present
    result = result.lstrip('\n')
    
    with open(output_file, 'w', encoding='utf-8') as f_out:
        f_out.write(result)

if __name__ == "__main__":
    print(f"Formatting {input_file}...")
    format_chat()
    print(f"Done! Output saved to {output_file}")
