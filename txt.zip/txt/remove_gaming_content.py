#!/usr/bin/env python3
"""
Script to remove Free Fire tournament and gaming related conversations
from the Bengali chat file.
"""

import re

def is_gaming_related(line):
    """Check if a line contains gaming/tournament related content."""
    gaming_keywords = [
        'ফ্রী ফিরে', 'ফ্রি ফায়ার', 'free fire', 'freefire',
        'তউরনামেন্ত', 'টুর্নামেন্ট', 'tournament',
        'সকুয়াদ', 'squad', 'তেয়াম', 'team',
        'প্লায়ের', 'player', 'কিল্ল', 'kill',
        'মচ', 'match', 'গেম', 'game',
        'স্নিপের', 'sniper', 'সনাইপের', 'সনিপের',
        'ফিরস্ত', 'first', 'ফিরে দিস', 'ফিরে দিয়',
        'অফ ফিরে', 'অফফ ফিরে',
        'এ-স্পরতস', 'esports', 'e-sports',
        'বেরমুদা', 'bermuda', 'মাপ', 'map',
        'দ্রপ পইন্ত', 'drop point',
        'প্রাচতিচে', 'practice',
        'চস', 'cs', 'ব্র', 'br',
        'হান্দলে', 'handle',
        'লেভেল ৪০', 'level',
        'স্কিল্ল', 'skill',
        'কুয়ালিফ্য', 'qualify',
        'স্লত', 'slot',
        'এস্পন্সার', 'sponsor',
        'ত্রিনিং', 'training',
        'মিচ অন', 'mic on',
        'পিন হিঘ', 'ping high',
        'দামাগে', 'damage',
        'গুলি করলে', 'গুলি',
        'মারতে পারব', 'মারসিল',
        'হেয়াদশত', 'headshot',
        'ট্রপ্র', 'drop',
        'জিমেইল বিন্দ', 'gmail bind',
        'অ্যাকাউন্ট নিয়ে খেল',
        'ইদ তে কত বসর খেল',
        'কিং অফ থে',
        'লভের', 'lover',
        'চমে বাচক', 'camper',
        'রতাতিওন', 'rotation',
        'পেরফেচত', 'perfect',
        'চাপে তওন', 'cape town',
        'সচ্রিম', 'scrim',
        'ডিপ দিতে', 'dip',
        'পের কিল্ল', 'per kill',
        'ফিরে দিয় না',  # gaming context - "don't fire"
        'ফিরে দিয়ে',    # gaming context
        'ফিরে আমাদের',  # gaming context
        'বকাছদা ফিরে',  # gaming context
        'নিশেদ করলাম ফিরে',  # gaming context
        'বলসি ফিরে',  # gaming context - "told to fire"
        'ড়িবাইব', 'revive',  # revive
        'ফিঘত', 'fight',  # fight
        'মিচ এ', 'mic',  # mic/match
        'ডিসকর্ড', 'discord',  # discord for gaming
        'পালাইতেচে',  # running away in game
        'মেরে দি',  # kill in game
    ]
    
    line_lower = line.lower()
    for keyword in gaming_keywords:
        if keyword.lower() in line_lower:
            return True
    return False

def find_conversation_blocks(lines):
    """
    Find blocks of conversation that are gaming related.
    Returns a set of line indices to remove.
    """
    lines_to_remove = set()
    
    # First pass: mark all gaming-related lines
    gaming_lines = set()
    for i, line in enumerate(lines):
        if is_gaming_related(line):
            gaming_lines.add(i)
    
    # Second pass: expand to include context (nearby lines in same conversation)
    for gaming_line in list(gaming_lines):
        # Look backwards for context (up to 10 lines or until empty/topic change)
        for j in range(gaming_line - 1, max(0, gaming_line - 11), -1):
            line = lines[j].strip()
            # Stop if line is empty or very short (likely topic change)
            if len(line) < 3:
                break
            # Check if this line is a simple response (emoji, short word)
            if len(line) < 25 or any(c in line for c in ['হু', 'হুম', 'ওক', 'হে', 'জে', 'কি', '🙂', '😭', '💋', '🫶', '🥲', 'শেশ', 'টী', '!']):
                lines_to_remove.add(j)
            elif is_gaming_related(line):
                lines_to_remove.add(j)
            else:
                break
        
        # Add the gaming line itself
        lines_to_remove.add(gaming_line)
        
        # Look forwards for context (up to 10 lines)
        for j in range(gaming_line + 1, min(len(lines), gaming_line + 11)):
            line = lines[j].strip()
            if len(line) < 3:
                break
            # Check if this line is a simple response
            if len(line) < 25 or any(c in line for c in ['হু', 'হুম', 'ওক', 'হে', 'জে', 'কি', '🙂', '😭', '💋', '🫶', '🥲', 'শেশ', 'টী', '!']):
                lines_to_remove.add(j)
            elif is_gaming_related(line):
                lines_to_remove.add(j)
            else:
                break
    
    return lines_to_remove

def process_file(input_file, output_file):
    """Process the file and remove gaming-related content."""
    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    print(f"Total lines in file: {len(lines)}")
    
    # Find lines to remove
    lines_to_remove = find_conversation_blocks(lines)
    print(f"Lines identified for removal: {len(lines_to_remove)}")
    
    # Create new content without gaming lines
    new_lines = []
    for i, line in enumerate(lines):
        if i not in lines_to_remove:
            new_lines.append(line)
    
    print(f"Lines remaining: {len(new_lines)}")
    
    # Write output
    with open(output_file, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)
    
    print(f"Output written to: {output_file}")

if __name__ == "__main__":
    # Process the formatted file
    process_file("Karib_Bengali_Formatted.txt", "Karib_Bengali_Formatted_Clean.txt")
