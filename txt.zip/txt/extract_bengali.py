import re

input_file = r'c:\Users\SHAWON\OneDrive\Desktop\txt\Karib_Bengali.txt'
output_file = r'c:\Users\SHAWON\OneDrive\Desktop\txt\Karib_Bengali_Only.txt'

def extract_bengali():
    with open(input_file, 'r', encoding='utf-8') as f_in, \
         open(output_file, 'w', encoding='utf-8') as f_out:
        
        for line in f_in:
            # Remove line numbers at the beginning (e.g., "  1 | ")
            line = re.sub(r'^\s*\d+\s*\|\s*', '', line)
            
            # Remove speaker attributions like "- কারিবঃ", "- মার্বান", etc.
            # Pattern: " - speaker_name" at the end or "speaker_name -" at the beginning
            line = re.sub(r'\s*-\s*(কারিবঃ|মার্বান|কারিব|মার্বান!)\s*$', '', line)
            line = re.sub(r'^\s*-\s*(কারিবঃ|মার্বান)\s*', '', line)
            
            # Clean up any remaining " - " patterns with names
            line = re.sub(r'\s*-\s*মার্বান\s*', '', line)
            line = re.sub(r'\s*-\s*কারিবঃ\s*', '', line)
            
            # Remove standalone speaker names
            clean_line = line.strip()
            if clean_line in ['কারিবঃ', 'মার্বান', '- মার্বান', '- কারিবঃ']:
                continue
            
            # Write non-empty lines
            if clean_line:
                f_out.write(clean_line + '\n')

if __name__ == "__main__":
    print(f"Extracting Bengali text from {input_file}...")
    extract_bengali()
    print(f"Done! Output saved to {output_file}")
