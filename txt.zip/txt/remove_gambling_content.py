#!/usr/bin/env python3
"""
Script to remove gambling/betting related conversations
from the Bengali chat file.
"""

import re

def is_gambling_related(line):
    """Check if a line contains gambling/betting related content."""
    gambling_keywords = [
        'জুয়া', 'জুয়ার', 'জুয়াই',
        'বাজি করত', 'বাজি ধর', 'বাজি খেল',
        'জায়া৭৭৭', 'জায়া777',
        'bet', 'betting', 'gambling',
        'হারাম', # in gambling context
    ]
    
    line_lower = line.lower()
    for keyword in gambling_keywords:
        if keyword.lower() in line_lower:
            return True
    return False

def find_conversation_blocks(lines):
    """
    Find blocks of conversation that are gambling related.
    Returns a set of line indices to remove.
    """
    lines_to_remove = set()
    
    # First pass: mark all gambling-related lines
    gambling_lines = set()
    for i, line in enumerate(lines):
        if is_gambling_related(line):
            gambling_lines.add(i)
    
    # Second pass: expand to include context (nearby lines in same conversation)
    for gambling_line in list(gambling_lines):
        # Look backwards for context (up to 5 lines)
        for j in range(gambling_line - 1, max(0, gambling_line - 6), -1):
            line = lines[j].strip()
            if len(line) < 3:
                break
            if len(line) < 25 or any(c in line for c in ['হু', 'হুম', 'ওক', 'হে', 'জে', 'কি', '🙂', '😭', '💋', '🫶', '🥲']):
                lines_to_remove.add(j)
            elif is_gambling_related(line):
                lines_to_remove.add(j)
            else:
                break
        
        # Add the gambling line itself
        lines_to_remove.add(gambling_line)
        
        # Look forwards for context (up to 5 lines)
        for j in range(gambling_line + 1, min(len(lines), gambling_line + 6)):
            line = lines[j].strip()
            if len(line) < 3:
                break
            if len(line) < 25 or any(c in line for c in ['হু', 'হুম', 'ওক', 'হে', 'জে', 'কি', '🙂', '😭', '💋', '🫶', '🥲']):
                lines_to_remove.add(j)
            elif is_gambling_related(line):
                lines_to_remove.add(j)
            else:
                break
    
    return lines_to_remove

def process_file(input_file, output_file):
    """Process the file and remove gambling-related content."""
    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    print(f"Total lines in file: {len(lines)}")
    
    # Find lines to remove
    lines_to_remove = find_conversation_blocks(lines)
    print(f"Lines identified for removal: {len(lines_to_remove)}")
    
    # Create new content without gambling lines
    new_lines = []
    for i, line in enumerate(lines):
        if i not in lines_to_remove:
            new_lines.append(line)
    
    print(f"Lines remaining: {len(new_lines)}")
    
    # Write output
    with open(output_file, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)
    
    print(f"Output written to: {output_file}")

if __name__ == "__main__":
    process_file("Karib_Bengali_Formatted.txt", "Karib_Bengali_Formatted_Clean.txt")
